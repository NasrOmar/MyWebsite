// JavaScript Document

function menuToggle(){
	var x = document.getElementById('navbar-toggler');
	var y = document.getElementById("nav-items-ul");
	
	x.classList.toggle("navbar-toggler-btn-x");
	y.classList.toggle("nav-items-height");
}
